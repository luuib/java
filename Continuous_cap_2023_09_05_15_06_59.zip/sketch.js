var num1= 100;
var num2= 10;

///console.log (num1=num2)

var soma

function calcularSoma (num1,num2) {
  soma= num1 + num2;
  return soma;
}

resultado = calcularSoma(num1,num2);
console.log('A soma é',num1 ,'e' ,num2,'é',resultado )

num1=300;
num2=40;

resultado = calcularSoma(num1,num2);
console.log("A soma é",resultado )